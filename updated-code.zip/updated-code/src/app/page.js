import Image from "next/image";
import FrontPage from "./pages/home/page";
import DefiFund from "./pages/defifund/page";

export default function Home() {
  return (
  <>
  {/* <FrontPage /> */}
  <DefiFund />
  </>
  );
}
