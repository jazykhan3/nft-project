// tailwind.config.js
module.exports = {
    darkMode: 'class', // important for dark/light mode toggle
    theme: {
      extend: {},
    },
    plugins: [],
  }
  